package com.dev.suhada.accessingmongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccessingMongodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccessingMongodbApplication.class, args);
	}

}

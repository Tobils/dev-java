package com.okta.spring.SpringBootOAuthClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootOAuthClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
